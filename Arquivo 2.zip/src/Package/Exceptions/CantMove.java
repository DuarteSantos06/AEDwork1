package Package.Exceptions;

public class CantMove extends Exception{

    public CantMove(String message){
        super(message);
    }
}
