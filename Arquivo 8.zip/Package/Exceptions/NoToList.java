package Package.Exceptions;

public class NoToList extends Exception{

    public NoToList(String message){
        super(message);
    }
}
