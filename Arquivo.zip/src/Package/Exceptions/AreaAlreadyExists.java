package Package.Exceptions;

public class AreaAlreadyExists extends Exception{

    public AreaAlreadyExists(String message){
        super(message);
    }
}
