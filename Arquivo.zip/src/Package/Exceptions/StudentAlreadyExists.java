package Package.Exceptions;

public class StudentAlreadyExists extends Exception{

    public StudentAlreadyExists(String message){
        super(message);
    }
}
