package Package.Exceptions;

public class AreaDoesNotExist extends Exception {
    public AreaDoesNotExist(String message) {
        super(message);
    }
}
