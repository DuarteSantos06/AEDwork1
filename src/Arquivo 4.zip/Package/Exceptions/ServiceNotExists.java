package Package.Exceptions;

public class ServiceNotExists extends Exception{
    public ServiceNotExists(String message){
        super(message);
    }
}
