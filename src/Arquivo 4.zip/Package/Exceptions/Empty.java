package Package.Exceptions;

public class Empty extends Exception{

    public Empty(String message){
        super(message);
    }
}
