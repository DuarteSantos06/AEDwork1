package Package.Exceptions;

public class ServiceAlreadyExists extends Exception{

    public ServiceAlreadyExists(String message){
        super(message);
    }
}
