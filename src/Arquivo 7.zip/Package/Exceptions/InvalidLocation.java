package Package.Exceptions;

public class InvalidLocation extends Exception{

    public InvalidLocation(String message){
        super(message);
    }
}
