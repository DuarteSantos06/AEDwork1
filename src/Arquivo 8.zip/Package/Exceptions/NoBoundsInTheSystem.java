package Package.Exceptions;

public class NoBoundsInTheSystem extends Exception{

    public NoBoundsInTheSystem(String message){
        super(message);
    }
}
