package Package.Exceptions;

public class InvalidStudentType extends Exception{

    public InvalidStudentType(String message){
        super(message);
    }
}
