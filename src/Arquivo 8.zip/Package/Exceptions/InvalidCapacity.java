package Package.Exceptions;

public class InvalidCapacity extends Exception{

    public InvalidCapacity(String message){
        super(message);
    }
}
