package Package.Services;

public class Eating extends ServicesWithCapacity {

    public Eating(long latitude, long longitude, float price, int capacity,String name){
        super(latitude,longitude,price,capacity,name,"eating");
    }
}
