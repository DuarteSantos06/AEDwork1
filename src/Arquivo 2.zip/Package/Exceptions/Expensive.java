package Package.Exceptions;

public class Expensive extends Exception{

    public Expensive(String message){
        super(message);
    }
}
