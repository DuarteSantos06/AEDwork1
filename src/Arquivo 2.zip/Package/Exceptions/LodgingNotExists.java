package Package.Exceptions;

public class LodgingNotExists extends Exception{

    public LodgingNotExists(String message){
        super(message);
    }
}
