package Package.Exceptions;

public class LodgingIsFull extends Exception{

    public LodgingIsFull(String message){
        super(message);
    }
}
