package Package.Exceptions;

public class InvalidType extends Exception{

    public InvalidType(String message){
        super(message);
    }
}
