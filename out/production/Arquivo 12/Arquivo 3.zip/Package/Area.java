//@author Duarte Santos (70847) djp.santos@campus.fct.unl.pt
//@author Rodrigo Marcelino (71260) r.marcelino@campus.fct.unl.pt
package Package;

import Package.Services.Services;
import Package.Students.Students;
import dataStructures.*;


import java.io.*;


public class Area implements AreaInterface, Serializable {

    private final String name;
    private final long topLatitude;
    private final long leftLongitude;
    private final long bottomLatitude;
    private final long rightLongitude;

    private transient Map<Integer,List<Services>> servicesByStar;
    private transient Map<String,Services> servicesByName;
    private transient List<Services> services;
    private transient Map<String,Students> students;
    private transient Map<String,List<Students>>studentsByRegistration;

    public Area(String name, long topLatitude, long leftLongitude, long bottomLatitude, long rightLongitude) {
        this.name = name;
        this.topLatitude = topLatitude;
        this.leftLongitude = leftLongitude;
        this.bottomLatitude = bottomLatitude;
        this.rightLongitude = rightLongitude;
        services = new ListInArray<>(2500);
        students = new RBSortedMap<>();
        studentsByRegistration = new SepChainHashTable<>();
        servicesByStar = new RBSortedMap<>();
        servicesByName = new SepChainHashTable<>();
    }

    public void updateEvaluation(Services service, int newStar,int oldStar){
        List<Services> list = servicesByStar.get(oldStar);
        list.remove(list.indexOf(service));
        List<Services> newList = servicesByStar.get(newStar);
        if(newList==null){
            newList = new DoublyLinkedList<>();
            servicesByStar.put(newStar,newList);
        }
        newList.addLast(service);
    }

    public String getName() {
        return name;
    }

    public Map<String,Services> getServicesByName(){
        return servicesByName;
    }

    public Map<Integer,List<Services>> getServicesByStar(){
        return servicesByStar;
    }

    public long getTopLatitude() {
        return topLatitude;
    }

    public long getLeftLongitude() {
        return leftLongitude;
    }

    public long getBottomLatitude() {
        return bottomLatitude;
    }

    public long getRightLongitude() {
        return rightLongitude;
    }

    public void addService(Services service){
        services.addLast(service);
        List<Services>list=servicesByStar.get(service.getEvaluation());
        if(list==null){
            list=new DoublyLinkedList<>();
            servicesByStar.put(service.getEvaluation(),list);
        }
        list.addLast(service);
        servicesByName.put(service.getName().toLowerCase(),service);
    }

    public void addStudent(Students student){
        students.put(student.getName().toLowerCase(),student);
        String country = student.getCountry().toLowerCase();
        List<Students> list = studentsByRegistration.get(country);
        if(list==null){
            list = new DoublyLinkedList<>();
            studentsByRegistration.put(country,list);
        }
        list.addLast(student);
    }

    public void removeStudent(Students student){
        students.remove(student.getName().toLowerCase());
        List<Students> list = studentsByRegistration.get(student.getCountry().toLowerCase());

        if (list != null) {
            list.remove(list.indexOf(student));
            if (list.isEmpty()) {
                studentsByRegistration.remove(student.getCountry().toLowerCase());
            }
        }
    }

    public List<Services> getServices(){
        return services;
    }

    public Map<String,Students> getStudents(){
        return students;
    }

    public List<Students> getStudentsByRegistrationByCountry(String country){
        return studentsByRegistration.get(country.toLowerCase());
    }

    /**
     * Serializes custom fields: services and studentsByRegistration.
     * This is a private helper for Java serialization.
     */
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        oos.writeInt(services.size());
        for (int i = 0; i < services.size(); i++) {
            oos.writeObject(services.get(i));
        }

        oos.writeInt(studentsByRegistration.size());
        for (Iterator<Map.Entry<String, List<Students>>> it = studentsByRegistration.iterator(); it.hasNext(); ) {
            Map.Entry<String, List<Students>> entry = it.next();
            String country = entry.key();
            List<Students> list = entry.value();

            oos.writeObject(country);
            oos.writeInt(list.size());

            for (int i = 0; i < list.size(); i++) {
                Students st = list.get(i);
                oos.writeObject(st);
            }
        }
    }

    /**
     * Deserializes custom fields: services and studentsByRegistration.
     * This is a private helper for Java serialization.
     */
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        this.services = new ListInArray<>(2500);
        this.students = new BSTSortedMap<>();
        this.studentsByRegistration = new SepChainHashTable<>();
        this.servicesByStar = new BSTSortedMap<>();
        this.servicesByName = new SepChainHashTable<>();

        int numServices = ois.readInt();
        for (int i = 0; i < numServices; i++) {
            Services s = (Services) ois.readObject();
            services.addLast(s);
        }
        for (int i=0;i<services.size();i++){
            List<Services> list = servicesByStar.get(services.get(i).getEvaluation());
            if(list==null){
                list=new DoublyLinkedList<>();
                servicesByStar.put(services.get(i).getEvaluation(),list);
            }
            list.addLast(services.get(i));
            servicesByName.put(services.get(i).getName().toLowerCase(),services.get(i));
        }

        int numCountries = ois.readInt();
        for (int i = 0; i < numCountries; i++) {
            String country = (String) ois.readObject();
            int listSize = ois.readInt();
            List<Students> list = new ListInArray<>(listSize);

            for (int j = 0; j < listSize; j++) {
                Students st = (Students) ois.readObject();
                list.addLast(st);
                students.put(st.getName().toLowerCase(),st);
            }

            studentsByRegistration.put(country, list);
        }
    }
}
