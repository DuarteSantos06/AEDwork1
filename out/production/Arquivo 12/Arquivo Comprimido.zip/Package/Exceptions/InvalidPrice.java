package Package.Exceptions;

public class InvalidPrice extends Exception{

    public InvalidPrice(String message){
        super(message);
    }
}
