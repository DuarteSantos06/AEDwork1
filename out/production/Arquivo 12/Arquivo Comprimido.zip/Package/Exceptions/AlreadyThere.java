package Package.Exceptions;

public class AlreadyThere extends Exception{

    public AlreadyThere(String message){
        super(message);
    }
}
