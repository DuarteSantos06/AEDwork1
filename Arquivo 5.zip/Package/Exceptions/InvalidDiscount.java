package Package.Exceptions;

public class InvalidDiscount extends Exception{

    public InvalidDiscount(String message){
        super(message);
    }
}
