package Package.Services;

public class Eating extends ServicesWithCapacity {

    public Eating(long latitude, long longitude, int price, int capacity,String name){
        super(latitude,longitude,price,capacity,name,"eating");
    }
}
