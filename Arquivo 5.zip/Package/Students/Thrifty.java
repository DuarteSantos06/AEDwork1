package Package.Students;

import Package.Services.Lodging;

public class Thrifty extends Students {

    public Thrifty(String name, String country, String lodging, Lodging home){
        super(name,country,lodging,home,"thrifty");
    }
}
